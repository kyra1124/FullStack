package com.example.demo.Entity;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee implements Serializable{
	
	@Id
	@Column(nullable = false, updatable = false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = false, updatable = false)
	private String empCode;
	
	private String name;
	private String jobTitle;

	private String phone;

	private String email;
	private String imageUrl;
	
	public Employee() {
		
	}
	
    @Autowired
	public Employee(long id, String empCode, String name, String jobTitle, String phone, String email,
			String imageUrl) {
		super();
		this.id = id;
		this.empCode = empCode;
		this.name = name;
		this.jobTitle = jobTitle;
		this.phone = phone;
		this.email = email;
		this.imageUrl = imageUrl;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", empCode=" + empCode + ", name=" + name + ", jobTitle=" + jobTitle + ", phone="
				+ phone + ", email=" + email + ", imageUrl=" + imageUrl + "]";
	}

	
	
	

	
	

}
