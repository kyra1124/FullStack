package com.example.demo.Service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Employee;
import com.example.demo.Exceprion.UserNotFoundException;
import com.example.demo.Repo.DaoRepo;

@Service
public class ServiceRepo {

	@Autowired
	private DaoRepo rep;
	
  
	public ServiceRepo(DaoRepo rep) {
		this.rep = rep;
	}
    
	
	
    public List<Employee> getAll(){
    	
    	return rep.findAll();
    }
    
    public Employee addEmployee(Employee employee) {
    	employee.setEmpCode(UUID.randomUUID().toString());
    	return rep.save(employee);
    }
	
    public Employee updateEmployee(Employee employee) {
    	return rep.save(employee);
    }
    
    public Employee findEmployeeById(long id) {
    	
    	return rep.findById(id).orElseThrow(()-> new UserNotFoundException("userbyid not found"));
    }
    
    public void deleteEmployee(long id){
    
    	rep.deleteById(id);
    	
    	
    }
	
}
