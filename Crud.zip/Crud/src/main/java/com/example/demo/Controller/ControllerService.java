package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Employee;
import com.example.demo.Service.ServiceRepo;

@RestController
@RequestMapping("/employee")
@CrossOrigin(origins="http://localhost:4200")
public class ControllerService {
	
	@Autowired
	private ServiceRepo repo;
	
	@GetMapping("/all")
	public ResponseEntity<List<Employee>> getEmployees(){
		List<Employee> employee =repo.getAll();
		return new ResponseEntity<>(employee,HttpStatus.OK);
		
	}
	
	@GetMapping("{id}")
	public ResponseEntity<Employee> findEmployeeById(@PathVariable("id") long id){
		Employee employee =repo.findEmployeeById(id);
		return new ResponseEntity<>(employee,HttpStatus.OK);
		
	}
	
	@PostMapping("/add")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee){
		Employee employees =repo.addEmployee(employee);
		return new ResponseEntity<>(employees,HttpStatus.CREATED);
		
	}
	@PutMapping("/update")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee){
		Employee newemployee =repo.addEmployee(employee);
		return new ResponseEntity<>(newemployee,HttpStatus.OK);
		
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteEmployee(@PathVariable("id") long id){
		        repo.deleteEmployee(id);
		return new ResponseEntity<>(HttpStatus.OK);
		
	}
	

}
