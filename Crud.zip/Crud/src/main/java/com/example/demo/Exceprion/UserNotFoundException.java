package com.example.demo.Exceprion;

public class UserNotFoundException extends RuntimeException {
	
	public UserNotFoundException(String message) {
		super(message);
		
	}

}
